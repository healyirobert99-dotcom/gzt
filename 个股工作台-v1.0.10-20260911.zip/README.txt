A/H 投研交易工作台  v1.0.10
======================================================================

本版性质：启动脚本交付修复。无业务功能变更、无数据库 Schema 变更、
无接口变更、无研究口径变更。

----------------------------------------------------------------------
一、启动
----------------------------------------------------------------------

方式 A（推荐，Windows 双击）
    启动工作台.bat

方式 B（命令行）
    python app/server.py

默认地址：http://127.0.0.1:8765
（浏览器会自动打开；如需关闭请用 --no-browser）

可选参数：
    --port 8765      指定端口
    --no-browser     不自动打开浏览器
    --seed           写入示例数据
    --backup [path]  启动前备份数据库

----------------------------------------------------------------------
二、运行环境
----------------------------------------------------------------------

Python 3.8+（3.13 已验证）。本工作台为纯标准库实现，
不需要安装任何第三方包（无 requirements.txt）。

【重要】关于 启动工作台.bat
    本脚本会依次探测可用的 Python 解释器：
        ① 受管的固定版本解释器
        ② 受管 versions 目录下的任意版本
        ③ py 启动器（官方 Python Launcher）
        ④ PATH 上的 python
    每个候选都会被**真实执行一次**并校验 sys.version_info >= (3,8)，
    并显式拒绝路径中含 WindowsApps 的候选 —— 因为
    %LOCALAPPDATA%\Microsoft\WindowsApps\python.exe 是
    Microsoft Store 的**执行别名存根，不是解释器**，
    运行它只会弹出应用商店（旧版脚本正是因此双击一闪而过）。
    若脚本提示找不到 Python，请从 https://www.python.org 安装并在
    安装时勾选 “Add python.exe to PATH”。

----------------------------------------------------------------------
三、数据
----------------------------------------------------------------------

数据库：data/workbench.db（SQLite，WAL 模式）
schema_version：1.0.10
本版为**空库交付**（securities / research / trade_plans / trades /
execution_reviews / decision_ledger 行数均为 0）。

导入格式（只接受固定 JSON，不做 AI / Markdown / Excel 解析）：
    ah-workbench-import      完整导入（identity + 可选 status +
                             research + trade_plan + 可选 execution）
    ah-workbench-execution   仅追加一条动态执行判断
示例文件：samples/json/example-full-import.json
          samples/json/example-execution-update.json
流程固定为两段式：解析预览（不写库）→ 用户确认 → 单一事务写入
（任一只失败整批回滚）。

----------------------------------------------------------------------
四、自检
----------------------------------------------------------------------

离线测试套件（合计 504 断言，预期全部 FAIL 0）：

    python tests/test_v102.py        # 38 PASS
    python tests/test_v103.py        # 60 PASS
    python tests/test_v105.py        # 25 PASS
    python tests/test_v106.py        # 28 PASS
    python tests/test_v107.py        # 127 PASS
    python tests/test_v108.py        # 129 PASS
    python tests/test_v109.py        # 83 PASS
    python tests/test_v110.py        # 14 PASS（本版新增：交付契约）

HTTP 端到端冒烟（自带临时端口与服务实例，不占用 8765）：

    python output/20260910-audit/smoke_v109_http.py    # 38 PASS
    python output/20260910-audit/smoke_v108_http.py    # 14 PASS

联网集成（需外网，可选）：

    python tests/test_integration_quote.py             # 14 PASS

----------------------------------------------------------------------
五、目录
----------------------------------------------------------------------

    app/server.py                 服务端（纯标准库 http.server + sqlite3）
    app/static/                   前端（index.html / app.js / style.css）
    data/workbench.db             数据库
    tests/                        测试套件
    samples/json/                 导入 JSON 示例
    output/20260910-audit/        交付审计文档 / Manifest / 冒烟脚本
    README.txt                    本文件
    启动工作台.bat                Windows 启动脚本

----------------------------------------------------------------------
六、边界
----------------------------------------------------------------------

- 系统只展示事实（价格区间关系、验证项状态），不生成任何买卖建议。
- 证券唯一身份只认 exchange + code；name 不一致只提示，不自动修改。
- 交易流水 trades 为 append-only，导入路径不触碰；execution 亦为 append-only。
- 行情涨 = 红，跌 = 绿（中国市场惯例）。
- 不实现：AI 自由文本解析 / Markdown 解析 / 文件拖拽 / 自动联网补全。
